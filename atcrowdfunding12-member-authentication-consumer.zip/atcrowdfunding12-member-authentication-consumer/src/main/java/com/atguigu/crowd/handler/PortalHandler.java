package com.atguigu.crowd.handler;

import com.atguigu.crowd.CorwdConstant;
import com.atguigu.crowd.MySQLRemoteService;
import com.atguigu.crowd.ResultEntity;
import com.atguigu.crowd.entity.vo.PortalTypeVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.jws.WebParam;
import java.util.List;

/**
 * @author shiyutao
 * @create 2022-01-24 17:07
 */
@Controller
public class PortalHandler {
    @Autowired
    private MySQLRemoteService mySQLRemoteService;
    @RequestMapping("/")
    public String toPortalPage(Model model){
        ResultEntity<List<PortalTypeVO>> listResultEntity = mySQLRemoteService.getportalTypeProjectData();
        String result = listResultEntity.getResult();
        if (ResultEntity.SUCCESS.equals(result)){
            List<PortalTypeVO> data = listResultEntity.getData();
            model.addAttribute(CorwdConstant.ATTR_NAME_PORTAL_DATA,data);
        }
        return "portal";
    }
}
