package com.atguigu.crowd.entity.vo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * @author shiyutao
 * @create 2022-02-01 14:45
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class DetailReturnVO implements Serializable {
    private static final long serialVersionUID = 1L;
    private Integer returnId;
    private Integer supportemoney;
    private Integer signalPurchase;
    private Integer purchase;
    private Integer supportCount;
    private Integer freight;
    private Integer returnDate;
    private String content;



}
