package com.atguigu.crowd.handler;
import com.atguigu.crowd.*;
import com.atguigu.crowd.entity.po.MemberPO;
import com.atguigu.crowd.entity.vo.MemberLoginVO;
import com.atguigu.crowd.entity.vo.MemberVO;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpSession;
import javax.websocket.Session;
import java.util.Objects;
import java.util.concurrent.TimeUnit;


/**
 * @author shiyutao
 * @create 2022-01-25 14:59
 */
@Controller
public class MemberHandler {
    @Autowired
    private RedisRemoteService redisRemoteService;
    @Autowired
    private MySQLRemoteService mySQLRemoteService;
    @RequestMapping("auth/member/logout")
    public String logout(HttpSession session){
        session.invalidate();
        return "redirect:http://localhost/";


    }
    @RequestMapping("auth/member/do/login")
    public String login(@RequestParam("loginacct") String loginacct, @RequestParam("userpswd")String userpswd,
                        ModelMap ModelMap , HttpSession session){
        ResultEntity<MemberPO> memberPOByLoginAcctRemote = mySQLRemoteService.getMemberPOByLoginAcctRemote(loginacct);
        if (ResultEntity.FAILED.equals(memberPOByLoginAcctRemote)){
            ModelMap.addAttribute(CorwdConstant.ATTR_NAME_MESSAGE,memberPOByLoginAcctRemote.getResult());
            return "member-login";

        }
        MemberPO data = memberPOByLoginAcctRemote.getData();
        if (data==null){
            ModelMap.addAttribute(CorwdConstant.ATTR_NAME_MESSAGE,CorwdConstant.MESSAGE_LONGIN_FAILED);
            return "member-login";
        }
        String userpswd1 = data.getUserpswd();
        BCryptPasswordEncoder bCryptPasswordEncoder = new BCryptPasswordEncoder();
        boolean matches = bCryptPasswordEncoder.matches(userpswd, userpswd1);
        if (matches!=true){
            ModelMap.addAttribute(CorwdConstant.ATTR_NAME_MESSAGE,CorwdConstant.MESSAGE_LONGIN_FAILED);
            return "member-login";
        }
        MemberLoginVO memberLoginVO = new MemberLoginVO(data.getId(),data.getEmail(),data.getUsername());
        session.setAttribute(CorwdConstant.ATTR_NAME_LOGIN_MEMBER,memberLoginVO);
        return "redirect:http://localhost/auth/member/to/center/page";

    }





    @RequestMapping("auth/do/member/register")
    public String register(MemberVO memberVO,ModelMap modelMap){



        String phoneNum = memberVO.getPhoneNum();
        String key=CorwdConstant.REDIS_CODE_PREFIX+phoneNum;
        ResultEntity<String> resultEntity = redisRemoteService.getRedisKeyStringValueRemote(key);
        String result = resultEntity.getResult();
        if(resultEntity.FAILED.equals(result)){
            modelMap.addAttribute(CorwdConstant.ATTR_NAME_MESSAGE,resultEntity.getMessage());
            return "member-reg";

        }
        String data = resultEntity.getData();
        if (data==null){
            modelMap.addAttribute(CorwdConstant.ATTR_NAME_MESSAGE,CorwdConstant.CODE_NOT_EXISTS);
            return "member-reg";

        }
        String code = memberVO.getCode();
        if (!Objects.equals(code,data)){
            modelMap.addAttribute(CorwdConstant.ATTR_NAME_MESSAGE,CorwdConstant.MESSAGE_CODE_INVALID);
            return "member-reg";
        }

       redisRemoteService.removeRedisKeyStringValueRemote(key);
        BCryptPasswordEncoder bCryptPasswordEncoder = new BCryptPasswordEncoder();
                String userpswd = memberVO.getUserpswd();
                String encode = bCryptPasswordEncoder.encode(userpswd);
                memberVO.setUserpswd(encode);
                MemberPO memberPO = new MemberPO();
                BeanUtils.copyProperties(memberVO,memberPO);
        ResultEntity<String> stringResultEntity = mySQLRemoteService.saveMember(memberPO);

        if(resultEntity.FAILED.equals(stringResultEntity.getResult())){
            modelMap.addAttribute(CorwdConstant.ATTR_NAME_MESSAGE,stringResultEntity.getMessage());
            return "member-reg";

        }


        return "member-login";


    }




    @ResponseBody
    @RequestMapping("auth/member/send/short/message.json")
    public ResultEntity<String> authMemberSendShortMessage(@RequestParam("phoneNum") String phoneNum){
        ResultEntity<String> stringResultEntity = CrowdUtil.shortMessage(phoneNum);
        if (ResultEntity.SUCCESS.equals(stringResultEntity.getResult())){
            String data = stringResultEntity.getData();
            data = data.substring(5, 9);

            String key= CorwdConstant.REDIS_CODE_PREFIX+phoneNum;
            ResultEntity<String> savecode = redisRemoteService.setRedisKeyValueRemoteWithTimeout(key, data, 10, TimeUnit.MINUTES);
            if (ResultEntity.SUCCESS.equals(savecode.getResult())){
                return ResultEntity.successwithoutdata();
            }else {
                return savecode;

            }
        }else {
            return stringResultEntity;

        }
    }

}
